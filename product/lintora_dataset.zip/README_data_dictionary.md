# Lintora dataset: data dictionary

All data is synthetic. Timestamps are UTC. Coverage: 2025-01-01 to 2026-06-30 (signups through 2026-05-31).

Lintora is a fictional code-quality SaaS. A team signs up for a 14-day free trial, connects a repository, and Lintora analyses their code and flags issues. At the end of the trial, the account either subscribes to a paid plan or lapses.

## accounts.csv (one row per account, i.e. a customer organisation)

| column | description |
|---|---|
| account_id | Account identifier |
| created_at | Signup timestamp (trial start) |
| acquisition_channel | organic_search, direct, referral, partner, paid_search, paid_social |
| country | ISO country code of the billing address |
| company_size | Employee band self-reported at signup |
| primary_language | Main programming language of the account's code |
| primary_scm | Source control platform (github, gitlab, bitbucket, azure_devops) |
| onboarding_version | Onboarding flow shown at signup (v1, or v2 which shipped 2025-10-01) |

## users.csv (one row per user seat)

| column | description |
|---|---|
| user_id | User identifier |
| account_id | Account the user belongs to |
| created_at | When the user joined the account |
| role | admin, developer, tech_lead |
| is_account_creator | True for the user who created the account |

## events.csv (client-side product analytics, one row per tracked event)

| column | description |
|---|---|
| event_id | Event identifier |
| event_timestamp | When the event was recorded |
| account_id, user_id | Who triggered it |
| event_name | account_created, repo_connected, ci_integration_connected, user_invited, session_start, analysis_run, ai_fix_accepted |
| client | web, ide_plugin, cli |
| client_version | Version of the client that sent the event ("web" for the web app) |

Notes: `ci_integration_connected` means the customer wired Lintora into their CI pipeline so analysis runs on every pull request. `ai_fix_accepted` means a user accepted an AI-generated fix suggestion (feature launched 2025-06-01).

## issue_activity_weekly.csv (server-side, one row per account per week with analyses)

| column | description |
|---|---|
| account_id | Account |
| week_start | Monday of the week |
| analyses_completed | Code analyses completed by the backend that week |
| issues_raised | Issues flagged by Lintora |
| issues_fixed | Issues the customer fixed |
| issues_dismissed_false_positive | Issues the customer dismissed, marking them "false positive" |

## subscriptions.csv (one row per paid subscription)

| column | description |
|---|---|
| subscription_id, account_id | Identifiers |
| plan | team, business, enterprise |
| billing_period | monthly or annual |
| start_date | First paid day (trial end) |
| end_date | Last day of service; empty if still active |
| status | active or canceled |
| cancellation_reason | customer_requested or payment_failed; empty if active |
| seats_start, seats_current | Seats at start and at end (or today, if active) |
| mrr_start_usd, mrr_current_usd | Monthly recurring revenue at start and at end/today (annual plans are shown as monthly equivalent) |

## payments.csv (one row per payment attempt)

| column | description |
|---|---|
| payment_id, account_id, subscription_id | Identifiers |
| attempted_at | When the charge was attempted |
| amount_usd | Amount charged (annual plans charge 12 months at once) |
| status | succeeded or failed |
| failure_code | Processor failure code, if failed |
| attempt_number | 1 = scheduled charge, 2 = automatic retry 3 days later |
| payment_method | card or invoice |

## marketing_spend_monthly.csv

| column | description |
|---|---|
| month | YYYY-MM |
| channel | paid_search, paid_social, partner (other channels have no direct spend) |
| spend_usd | Spend in the month |
